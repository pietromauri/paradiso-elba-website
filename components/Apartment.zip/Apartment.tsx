
import React from 'react';
import { Icons, GALLERY_IMAGES } from '../constants';

const apartmentImages = GALLERY_IMAGES.filter(img => img.category === 'appartamento');

const Feature: React.FC<{ icon: React.ReactNode; label: string; description: string }> = ({ icon, label, description }) => (
  <div className="flex items-start space-x-4">
    <div className="flex-shrink-0 text-teal-600">{icon}</div>
    <div>
      <h4 className="font-bold text-lg">{label}</h4>
      <p className="text-gray-600">{description}</p>
    </div>
  </div>
);

const CalendarDay: React.FC<{ day?: number; isAvailable?: boolean }> = ({ day, isAvailable = false }) => (
  <div className={`text-center py-2 border ${day ? '' : 'bg-gray-50'} ${day && !isAvailable ? 'bg-red-100 text-gray-400 line-through' : ''} ${day && isAvailable ? 'bg-green-100' : ''}`}>
    {day || ''}
  </div>
);

const Apartment: React.FC = () => {
  const daysInMonth = Array.from({ length: 31 }, (_, i) => i + 1);
  const unavailableDays = [3, 4, 5, 12, 18, 19, 20, 21, 28];

  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 py-20">
        {/* Description */}
        <section className="text-center">
          <h2 className="text-5xl font-serif text-gray-800">Un Nido di Comfort e Stile</h2>
          <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-600">
            Svegliati con il suono delle onde, fai colazione sulla nostra terrazza baciata dal sole e lasciati avvolgere dalla tranquillità di un ambiente pensato per il tuo benessere. Ogni dettaglio è curato per offrirti un soggiorno indimenticabile.
          </p>
        </section>

        {/* Photo Gallery */}
        <section className="mt-20">
          <h3 className="text-4xl font-serif text-center mb-10">Galleria Fotografica Immersiva</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {apartmentImages.map((img, index) => (
              <div key={img.id} className={`${index === 0 ? 'col-span-2 row-span-2' : ''} overflow-hidden rounded-lg shadow-lg`}>
                <img src={img.src} alt={img.alt} className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500" />
              </div>
            ))}
          </div>
        </section>

        {/* Features & Services */}
        <section className="mt-20">
          <h3 className="text-4xl font-serif text-center mb-12">Caratteristiche e Servizi</h3>
          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
            <Feature icon={<Icons.Bed />} label="4 Posti Letto" description="Una camera matrimoniale e una camera con due letti singoli." />
            <Feature icon={<Icons.Wifi />} label="Wi-Fi Alta Velocità" description="Connessione in fibra ottica per streaming e smart working." />
            <Feature icon={<Icons.AirConditioning />} label="Aria Condizionata" description="Climatizzazione in ogni ambiente per il massimo comfort." />
            <Feature icon={<Icons.Parking />} label="Parcheggio Privato" description="Un posto auto riservato a pochi passi dall'ingresso." />
            <Feature icon={<Icons.Kitchen />} label="Cucina Attrezzata" description="Macchina caffè, lavastoviglie, microonde e tutto il necessario." />
            <Feature icon={<Icons.Tv />} label="Smart TV & Extra" description="TV con Netflix, lavatrice, barbecue e doccia esterna." />
          </div>
        </section>

        {/* Layout & Map */}
        <section className="mt-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-4xl font-serif mb-6">Disposizione e Posizione</h3>
            <p className="text-gray-600 mb-8">Comprendi al meglio gli spazi con la nostra planimetria 3D e scopri la comodità della nostra posizione: a soli 200 metri dalla spiaggia di Procchio e vicina a tutti i servizi essenziali.</p>
            <img src="https://i.imgur.com/ABnj53A.jpeg" alt="Planimetria 3D dell'appartamento" className="rounded-lg shadow-xl w-full" />
          </div>
          <div>
            <a href="https://www.google.com/maps/place/Procchio,+Marciana,+LI,+Italy" target="_blank" rel="noopener noreferrer">
              <img src="https://i.imgur.com/w21xV1z.png" alt="Mappa della posizione dell'appartamento" className="rounded-lg shadow-xl w-full border" />
            </a>
          </div>
        </section>

        {/* Availability Calendar */}
        <section className="mt-20">
          <h3 className="text-4xl font-serif text-center mb-10">Disponibilità e Prezzi</h3>
          <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-2xl">
            <div className="flex justify-between items-center mb-4">
                <button className="px-3 py-1">&larr;</button>
                <h4 className="text-2xl font-semibold">Luglio 2024</h4>
                <button className="px-3 py-1">&rarr;</button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-sm">
                {['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'].map(day => <div key={day} className="text-center font-bold text-gray-600 py-2">{day}</div>)}
                {daysInMonth.map(day => <CalendarDay key={day} day={day} isAvailable={!unavailableDays.includes(day)} />)}
            </div>
             <div className="mt-6 flex items-center justify-center space-x-6">
                <div className="flex items-center"><span className="w-4 h-4 bg-green-100 border mr-2"></span> Disponibile</div>
                <div className="flex items-center"><span className="w-4 h-4 bg-red-100 border mr-2"></span> Prenotato</div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Apartment;
